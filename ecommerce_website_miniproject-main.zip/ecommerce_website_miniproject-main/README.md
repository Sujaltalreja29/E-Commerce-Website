# ecommerce_website_miniproject
this is an small website created using CSS and HTML. which contains 4-5 pages regarding there category
